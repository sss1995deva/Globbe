<?php 
 
	 $db =  "id9857698_newdb";//"test";
	$user = "id9857698_root1234";
	$pass = "12345678";
	$host = "localhost";
	
	$con = mysqli_connect($host,$user,$pass,$db);
	
	//Getting the page number which is to be displayed  
	$page = $_GET['page'];	
	
	//Initially we show the data from 1st row that means the 0th row 
	$start = 0; 
	
	//Limit is 3 that means we will show 3 items at once
	$limit = 1; 
	
	//Counting the total item available in the database 
	$total = mysqli_num_rows(mysqli_query($con, "SELECT eventName FROM event"));
	
	//We can go atmost to page number total/limit
	$page_limit = $total/$limit; 
	
	//If the page number is more than the limit we cannot show anything 
	if($page<=$page_limit){
		
		//Calculating start for every given page number 
		$start = ($page - 1) * $limit; 
		
		//SQL query to fetch data of a range 
		$sql = "SELECT * FROM event  ORDER BY timeStamps DESC limit $start, $limit";
 
		//Getting result 
		$result = mysqli_query($con,$sql); 
		
		//Adding results to an array 
		$res = array(); 
 
		while($row = mysqli_fetch_array($result)){
			array_push($res, array(

				"instituteName"=>$row['instituteName'],
				
				"eventName"=>$row['eventName'],

				"typeEvent"=>$row['typeEvent'],
				
				"topicEvent"=>$row['topicEvent'],
				
				"timeStamp"=>$row['timeStamps'],
				
				"targetAudience"=>$row['targetAudience'],
				
				"shortDescription"=>$row['shortDescription'],
				
				"eventstartTime"=>$row['eventstartTime'],
				
				"eventendTime"=>$row['eventendTime'],
				
				"eventstartDate"=>$row['eventstartDate'],
				
				"eventendtDate"=>$row['eventendDate'],
                
                "eventAddress"=>$row['eventAddress'],
				
				"eventPaid"=>$row['eventPaid'])

				);
		}
		//Displaying the array in json format 
		echo json_encode($res);
	}else{
            echo "over";
	}
?>