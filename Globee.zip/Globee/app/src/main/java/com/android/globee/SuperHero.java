package com.android.globee;

class SuperHero {
    //Data Variables
    private String instituteName;
    private String eventName;
    private String timeStamps;
    private String typeOfEvent;
    private String topicOfEvent;
    private String targetAudience;
    private String shortDescription;
    private String eventstartTime;
    private String eventendTime;
    private String eventstartDate;
    private String eventendDate;
    private String eventAddress;

    String getInstituteName() {
        return instituteName;
    }

    void setInstituteName(String instituteName) {
        this.instituteName = instituteName;
    }

    String getEventName() {
        return eventName;
    }

    void setEventName(String eventName) {
        this.eventName = eventName;
    }

    String getEventstartDate() {
        return eventstartDate;
    }

    void setEventstartDate(String eventstartDate) {
        this.eventstartDate = eventstartDate;
    }

    String getEventendDate() {
        return eventendDate;
    }

    void setEventendDate(String eventendDate) {
        this.eventendDate = eventendDate;
    }

    private String eventPaid;

    String getEventstartTime() {
        return eventstartTime;
    }

    void setEventstartTime(String eventstartTime) {
        this.eventstartTime = eventstartTime;
    }

    String getEventendTime() {
        return eventendTime;
    }

     void setEventendTime(String eventendTime) {
        this.eventendTime = eventendTime;
    }

    String getTimeStamps() {
        return timeStamps;
    }

     void setTimeStamps(String timeStamps) {
        this.timeStamps = timeStamps;
    }

     String getTypeOfEvent() {
        return typeOfEvent;
    }

     void setTypeOfEvent(String typeOfEvent) {
        this.typeOfEvent = typeOfEvent;
    }

     String getTopicOfEvent() {
        return topicOfEvent;
    }

     void setTopicOfEvent(String topicOfEvent) {
        this.topicOfEvent = topicOfEvent;
    }

    String getTargetAudience() {
        return targetAudience;
    }

     void setTargetAudience(String targetAudience) {
        this.targetAudience = targetAudience;
    }

    String getShortDescription() {
        return shortDescription;
    }

     void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

     String getEventAddress() {
        return eventAddress;
    }

     void setEventAddress(String eventAddress) {
        this.eventAddress = eventAddress;
    }

     String getEventPaid() {
        return eventPaid;
    }

    void setEventPaid(String eventPaid) {
        this.eventPaid = eventPaid;
    }
}
