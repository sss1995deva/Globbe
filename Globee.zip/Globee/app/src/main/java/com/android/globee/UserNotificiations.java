package com.android.globee;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class UserNotificiations extends BaseAdapter {
    private Context mContext;
    private ArrayList<String> time;
    private ArrayList<String> sname;
    private ArrayList<String> eventName;

    public UserNotificiations(Context c, ArrayList<String> time, ArrayList<String> sname, ArrayList<String> eventName)
    {
        this.mContext = c;


        this.time = time;
        this.sname = sname;
        this.eventName = eventName;
    }


    public int getCount() {
        return sname.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int pos, View child, ViewGroup arg2) {
        Holder mHolder;
        LayoutInflater layoutInflater;
        if (child == null) {
            layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            child = layoutInflater.inflate(R.layout.fragment_new_message, null);
            mHolder = new Holder();

            mHolder.sname =  child.findViewById(R.id.userName);
            mHolder.time =  child.findViewById(R.id.eventTypes);
            mHolder.eventName =  child.findViewById(R.id.eventNames);
            child.setTag(mHolder);
        } else {
            mHolder = (Holder) child.getTag();
        }
        //mHolder.txt_id.setText(id.get(pos));
        mHolder.time.setText(time.get(pos));
        mHolder.sname.setText(sname.get(pos));
        mHolder.eventName.setText(eventName.get(pos));
        return child;
    }

    public class Holder
    {
        TextView eventName,time,sname;
    }
}
