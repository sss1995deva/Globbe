package com.android.globee;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    Button regButton;
    Button login;
    SessionManagement sessionManagement;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sessionManagement = new SessionManagement(getApplicationContext());

        if (sessionManagement.isLoggedIn()) {
            startActivity(new Intent(MainActivity.this, UserHome.class));
        }
        else {
            regButton = findViewById(R.id.registerButton);
            regButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, UserRegister.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                }
            });

            login = findViewById(R.id.loginButton);
            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, UserLogin.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        //  super.onBackPressed();
    }
}


/*

elsQMdsvTZqXHYGVifLcZl:APA91bGMoBaIVk_RMyKttlpr2-ueOMDbhLbOyOXzlS-EMOLhgd3dZUIK3L_LA5NmcEpCO9l__ImPPbwPPDHo0DrGJSfJft8oSVPUKCmurppd9JFEVQ-MDt3wc_E5HefXnmY_2BxfULeT
*/