package com.android.globee;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;

public class CardAdapter extends RecyclerView.Adapter<CardAdapter.ViewHolder> {

    private String finalResult;
    private HashMap<String, String> hashMap = new HashMap<>();
    private String HttpURL = "https:/stilted-cries.000webhostapp.com/eventRegister.php";
    private BackgroundRegister backgroundRegister = new BackgroundRegister();
    private Context context;
    private String insName,esName,studentEmail;
    private ProgressDialog progressDialog;
    private AlertDialog builder;
    //List to store all superheroes
    private List<SuperHero> superHeroes;

    //Constructor of this class
    CardAdapter(List<SuperHero> superHeroes, Context context) {
        super();
        //Getting all superheroes
        this.superHeroes = superHeroes;
        this.context = context;
        builder = new AlertDialog.Builder(this.context).create();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.superheroes_list, parent, false);
        return new ViewHolder(v);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        //Getting the particular item from the list
        SuperHero superHero = superHeroes.get(position);

        holder.timeStamps.setText(superHero.getTimeStamps());
        holder.instituteName.setText(superHero.getInstituteName());
        holder.eventName.setText(superHero.getEventName());
        holder.typeOfEvent.setText(superHero.getTypeOfEvent());
        holder.topicOfEvent.setText(superHero.getTopicOfEvent());
        holder.targetAudience.setText(superHero.getTargetAudience());
        holder.shortDescription.setText(superHero.getShortDescription());
        holder.eventstartTime.setText(superHero.getEventstartTime());
        holder.eventendtTime.setText(superHero.getEventendTime());
        holder.eventstartDate.setText(superHero.getEventstartDate());
        holder.eventendDate.setText(superHero.getEventendDate());
        holder.eventAddress.setText(superHero.getEventAddress());
        holder.eventPaid.setText(superHero.getEventPaid());

    }


    @Override
    public int getItemCount() {
        return superHeroes.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        //Views
        private TextView instituteName,eventName, timeStamps, typeOfEvent, topicOfEvent, targetAudience, shortDescription,
                eventstartTime, eventendtTime, eventstartDate, eventendDate, eventAddress,
                eventPaid;

        //Initializing Views
        ViewHolder(View itemView) {
            super(itemView);
            instituteName = itemView.findViewById(R.id.iname);

            eventName = itemView.findViewById(R.id.eventName);

            timeStamps = itemView.findViewById(R.id.timestamp);
            typeOfEvent = itemView.findViewById(R.id.typeOfEvent);
            topicOfEvent = itemView.findViewById(R.id.topicOfEvent);
            targetAudience = itemView.findViewById(R.id.targetAudience);
            shortDescription = itemView.findViewById(R.id.shortDescription);
            eventstartTime = itemView.findViewById(R.id.eventstartTime);
            eventendtTime = itemView.findViewById(R.id.eventendTime);
            eventstartDate = itemView.findViewById(R.id.eventstartDate);
            eventendDate = itemView.findViewById(R.id.eventendDate);
            eventAddress = itemView.findViewById(R.id.eventAddress);
            eventPaid = itemView.findViewById(R.id.eventPaid);


            SessionManagement sessionManagement = new SessionManagement(context);
            sessionManagement.checkLogin();
            HashMap<String, String>  student = sessionManagement.getUserDetails();
            studentEmail = student.get(SessionManagement.KEY_EMAIL);


            Button eventRegister = itemView.findViewById(R.id.eventRegister);
            eventRegister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    insName = instituteName.getText().toString();
                    esName = eventName.getText().toString();

                    UserRegisterFunction(insName,esName,studentEmail);
                }
            });

        }
        private void UserRegisterFunction(final String insName,final String esName,final String studentEmail){

            @SuppressLint("StaticFieldLeak")
            class UserRegisterFunctionClass extends AsyncTask<String,Void,String> {

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();

                    progressDialog = ProgressDialog.show(context,"Loading Data",null,true,true);
                }

                @Override
                protected void onPostExecute(String httpResponseMsg) {

                    super.onPostExecute(httpResponseMsg);
                    progressDialog.dismiss();
                      if(httpResponseMsg.contains("Registration Successfully")) {
                          builder.setTitle("Notice ");
                          builder.setMessage("Registration Successfully");
                          builder.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                  new DialogInterface.OnClickListener() {
                                      public void onClick(DialogInterface dialog, int which) {
                                          dialog.dismiss();
                                      }
                                  });
                          builder.show();
                      }
                     else if (httpResponseMsg.contains("Email Already Exists"))
                      {
                                builder.setTitle("Notice ");
                                builder.setMessage("You already register please check your dashboard");
                                  builder.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                 new DialogInterface.OnClickListener() {
                                     public void onClick(DialogInterface dialog, int which) {
                                         dialog.dismiss();
                                     }
                                 });
                                  builder.show();
                      }
                      else if (httpResponseMsg.contains("Institute Email"))
                      {
                          builder.setTitle("Notice ");
                          builder.setMessage("You cannot registered as a institute");
                          builder.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                  new DialogInterface.OnClickListener() {
                                      public void onClick(DialogInterface dialog, int which) {
                                          dialog.dismiss();
                                      }
                                  });
                          builder.show();
                      }

                }

                @Override
                protected String doInBackground(String... params) {

                    hashMap.put("insName",params[0]);

                    hashMap.put("esName",params[1]);

                    hashMap.put("studentEmail",params[2]);

                    finalResult = backgroundRegister.postRequest(hashMap, HttpURL);

                    return finalResult;
                }
            }

            UserRegisterFunctionClass userRegisterFunctionClass = new UserRegisterFunctionClass();
            userRegisterFunctionClass.execute(insName,esName,studentEmail);
        }
    }
}