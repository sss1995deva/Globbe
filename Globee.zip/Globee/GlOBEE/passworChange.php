<?php
$db =    "id9857698_newdb";//"test";
$user = "id9857698_root1234";
$pass = "12345678";
$host = "localhost";

if($_SERVER['REQUEST_METHOD']=='POST'){

	$con = mysqli_connect($host,$user,$pass,$db);

       $opassword = $_POST['oldPassword'];
       $npassword = $_POST['newPassword'];

       $studentEmail = $_POST['studentEmail'];

    $sql="UPDATE Student SET spassword='$npassword' WHERE semail = '$studentEmail' && 
                  spassword = '$opassword'";
       
       		if (mysqli_query($con,$sql))
       		{
       		    if((mysqli_affected_rows($con) != 0) ? true : false)
		            	echo "Change Successfully";
		       	else{
                		echo "Not Change";
                }
       		    
       		}
       mysqli_close($con);							
}
 

?>
