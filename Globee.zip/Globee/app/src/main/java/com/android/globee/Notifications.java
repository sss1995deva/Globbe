package com.android.globee;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class Notifications extends Fragment {
       public Notifications() {}
    private static final String DATA_URL = "https:/stilted-cries.000webhostapp.com/newMessage.php";
    private String studentEmail;
    private ProgressDialog progressDialog;
    private ArrayList<String> sname = new ArrayList<>();
    private ArrayList<String>  event = new ArrayList<>();
    private ArrayList<String> time = new ArrayList<>();
     private ListView userList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notifications, container, false);

        userList = view.findViewById(R.id.message_list);
        SessionManagement sessionManagement = new SessionManagement(getActivity());
        sessionManagement.checkLogin();
        HashMap<String, String>  student = sessionManagement.getUserDetails();
        studentEmail = student.get(SessionManagement.KEY_EMAIL);

        MyAsyncTasks myAsyncTasks = new MyAsyncTasks();
        myAsyncTasks.execute();

        return view;
    }

@SuppressLint("StaticFieldLeak")
public class MyAsyncTasks extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // display a progress dialog for good user experiance
            progressDialog = new ProgressDialog(getContext());
            progressDialog.setMessage("Please Wait");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        @Override
        protected String doInBackground(String... params) {
           String current = "";
            try {
                URL url;
                HttpURLConnection urlConnection = null;
                try {
                    url = new URL(DATA_URL);

                    urlConnection = (HttpURLConnection) url.openConnection();

                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    Uri.Builder builder = new Uri.Builder()
                            .appendQueryParameter("studentEmail", studentEmail);

                    Log.i("StudentEmail",studentEmail);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, StandardCharsets.UTF_8));

                    writer.write(Objects.requireNonNull(builder.build().getEncodedQuery()));
                    writer.flush();
                    writer.close();
                    os.close();
                    urlConnection.connect();

                    InputStream in = urlConnection.getInputStream();

                    InputStreamReader isw = new InputStreamReader(in);

                    int data = isw.read();
                    while (data != -1) {
                        current += (char) data;
                        data = isw.read();
                        System.out.print(current);

                    }
                    // return the data to onPostExecute method
                    return current;

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                return "Exception: " + e.getMessage();
            }
            return current;
        }

        @Override
        protected void onPostExecute(String s) {

            // dismiss the progress dialog after receiving data from API
            progressDialog.dismiss();
            try {
                // JSON Parsing of data
                JSONArray jsonArray = new JSONArray(s);

                // Pulling items from the array
                for(int i = 0; i < jsonArray.length(); i++){
                    JSONObject oneObject = jsonArray.getJSONObject(i);
                         time.add(oneObject.getString("time"));
                          sname.add(oneObject.getString("sname"));
                          event.add(oneObject.getString("eventName"));
                }

                UserNotificiations userNotificiations = new UserNotificiations(getActivity(),time, sname,event);
                userList.setAdapter(userNotificiations);



            } catch (JSONException e) {

                e.printStackTrace();
            }


        }

    }
}

