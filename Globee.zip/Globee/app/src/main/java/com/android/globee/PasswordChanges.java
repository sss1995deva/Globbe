package com.android.globee;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import java.util.HashMap;

public class PasswordChanges extends Fragment {
     public PasswordChanges() {  }

    private EditText oldPassword,newPassword,confirmPassword;
    private String HttpURL = "https:/stilted-cries.000webhostapp.com/passworChange.php";
     private String opassword;
    private String npassword;
    private String studentEmail;
    private Boolean CheckEditText ;
    private ProgressDialog progressDialog;
    private String finalResult ;
    private HashMap<String,String> hashMap = new HashMap<>();
    private SessionManagement sessionManagement;
    private BackgroundRegister backgroundRegister = new BackgroundRegister();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_password_changes, container, false);
        oldPassword = view.findViewById(R.id.oldPassword);
        newPassword = view.findViewById(R.id.newPassword);
        confirmPassword = view.findViewById(R.id.newwonPassword);

        sessionManagement = new SessionManagement(getActivity());
        sessionManagement.checkLogin();
        HashMap<String, String>  student = sessionManagement.getUserDetails();
        studentEmail = student.get(SessionManagement.KEY_EMAIL);

        Button passwwordChange = view.findViewById(R.id.submitButton);
        passwwordChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckEditTextIsEmptyOrNot();

                // If EditText is empty then this block will execute .
                if(CheckEditText){
                UserPasswordChange();
                }
                else
                    Toast.makeText(getActivity(), "Please fill all form fields.", Toast.LENGTH_LONG).show();

            }
        });

        return view;
    }
    private void CheckEditTextIsEmptyOrNot(){
           opassword = oldPassword.getText().toString();
           npassword = newPassword.getText().toString();
        String cpassword = confirmPassword.getText().toString();

        if(TextUtils.isEmpty(opassword) || TextUtils.isEmpty(npassword) || TextUtils.isEmpty(cpassword) )
        {

            CheckEditText = false;

        }
        else if (npassword.equals(cpassword)) {
            CheckEditText = true;
        }

        else {
            Toast.makeText(getActivity(), "Both password not match.", Toast.LENGTH_LONG).show();
            CheckEditText = false;
        }

    }
    private void UserPasswordChange()
    {
        @SuppressLint("StaticFieldLeak")
        class UserPasswordChangeClass extends AsyncTask<String,Void,String>{

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(getActivity(),"Loading Data",null,true,true);
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {
                super.onPostExecute(httpResponseMsg);

                progressDialog.dismiss();
                if(httpResponseMsg.contains("Change Successfully")) {
                    sessionManagement.createLoginSession(studentEmail,npassword);
                    Toast.makeText(getActivity(), "Change Successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getActivity(), UserHome.class);
                    startActivity(intent);
                }
                else if (httpResponseMsg.contains("Not Change"))
                {
                    Toast.makeText(getActivity(), "You Enter Wrong Password", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getActivity(), EventRegister.class);
                    startActivity(intent);
                }
            }

            @Override
            protected String doInBackground(String... params) {

                hashMap.put("oldPassword",params[0]);

                hashMap.put("newPassword",params[1]);

                hashMap.put("studentEmail",params[2]);

               finalResult = backgroundRegister.postRequest(hashMap, HttpURL);

                return finalResult;
                 }
        }


    UserPasswordChangeClass userRegisterFunctionClass = new UserPasswordChangeClass();
    userRegisterFunctionClass.execute(opassword,npassword,studentEmail);
}
}