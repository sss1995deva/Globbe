package com.android.globee;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Objects;

public class EventRegister extends Fragment {
    private EditText eventName,typeEvent,topicEvent,targetAudience,shortDescription,eventStartTime,eventEndTime,eventStartDate,eventEndDate,eventAddress,eventPaid;
    private String eName,tyEvent,toEvent,tAudience,sDescription,esTime,edTime,esDate,edDate,eAddress,ePaid;
    private String finalResult ;
    private String HttpURL = "https:/stilted-cries.000webhostapp.com/createEvent.php";
    private Boolean CheckEditText ;
    private ProgressDialog progressDialog;
    private HashMap<String,String> hashMap = new HashMap<>();
    private BackgroundRegister backgroundRegister = new BackgroundRegister();
    private DatePickerDialog datePickerDialog;
    private TimePickerDialog timePickerDialog;

    public EventRegister(){       }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_event_register, container, false);

        eventName =    view.findViewById(R.id.nameEvent);
        typeEvent =  view.findViewById(R.id.typeEvent);
        topicEvent = view.findViewById(R.id.topicEvent);
        targetAudience = view.findViewById(R.id.audienceEvent);
        shortDescription =  view.findViewById(R.id.descriptionEvent);

        eventStartTime =  view.findViewById(R.id.starttimeEvent);
        eventEndTime   =  view.findViewById(R.id.endtimeEvent);

        eventStartDate =  view.findViewById(R.id.startdateEvent);
        eventEndDate =   view.findViewById(R.id.enddateEvent);

        eventAddress =   view.findViewById(R.id.addressOfEvent);
        eventPaid =  view.findViewById(R.id.ePaid);

        SessionManagement sessionManagement = new SessionManagement(getContext());
        sessionManagement.checkLogin();
        HashMap<String, String>  institute = sessionManagement.getUserDetails();
        final String instituteEmail = institute.get(SessionManagement.KEY_EMAIL);

        eventStartDate.setInputType(InputType.TYPE_NULL);
        eventStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                datePickerDialog = new DatePickerDialog(Objects.requireNonNull(getActivity()),
                        new DatePickerDialog.OnDateSetListener() {
                            @SuppressLint("DefaultLocale")
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                eventStartDate.setText(String.format("%d/%d/%d", dayOfMonth, monthOfYear + 1, year));
                            }
                        }, year, month, day);
                datePickerDialog.show();
            }
        });
        eventEndDate.setInputType(InputType.TYPE_NULL);
        eventEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                datePickerDialog = new DatePickerDialog(Objects.requireNonNull(getActivity()),
                        new DatePickerDialog.OnDateSetListener() {
                            @SuppressLint("SetTextI18n")
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                eventEndDate.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

        eventStartTime.setInputType(InputType.TYPE_NULL);
        eventStartTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar= Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minutes = calendar.get(Calendar.MINUTE);
                // time picker dialog
                timePickerDialog = new TimePickerDialog(getActivity(),
                        new TimePickerDialog.OnTimeSetListener() {
                            @SuppressLint("DefaultLocale")
                            @Override
                            public void onTimeSet(TimePicker tp, int sHour, int sMinute) {
                                eventStartTime.setText(String.format("%d:%d", sHour, sMinute));
                            }
                        }, hour, minutes, true);
                timePickerDialog.show();
            }
        });

        eventEndTime.setInputType(InputType.TYPE_NULL);
        eventEndTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int hour = cldr.get(Calendar.HOUR_OF_DAY);
                int minutes = cldr.get(Calendar.MINUTE);
                // time picker dialog
                timePickerDialog = new TimePickerDialog(getActivity(),
                        new TimePickerDialog.OnTimeSetListener() {
                            @SuppressLint("DefaultLocale")
                            @Override
                            public void onTimeSet(TimePicker tp, int sHour, int sMinute) {
                                eventEndTime.setText(String.format("%d:%d", sHour, sMinute));
                            }
                        }, hour, minutes, true);
                timePickerDialog.show();
            }
        });

        Button createEvent = view.findViewById(R.id.createEvent);
        createEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Checking whether EditText is Empty or Not
                CheckEditTextIsEmptyOrNot();

                // If EditText is empty then this block will execute .
                // If EditText is not empty and CheckEditText = True then this block will execute.
                if(CheckEditText)
                    UserRegisterFunction(eName, tyEvent, toEvent, tAudience, sDescription, esTime, edTime, esDate, edDate, eAddress, ePaid, instituteEmail);
                else {
                    Toast.makeText(getActivity(), "Please fill all form fields.", Toast.LENGTH_LONG).show();
                }
            }
        });
        return view;
    }

    private void CheckEditTextIsEmptyOrNot(){

        eName  =  eventName.getText().toString();
        tyEvent = typeEvent.getText().toString();
        toEvent = topicEvent.getText().toString();
        tAudience = targetAudience.getText().toString();
        sDescription = shortDescription.getText().toString();
        esTime  = eventStartTime.getText().toString();
        edTime = eventEndTime.getText().toString();
        esDate = eventStartDate.getText().toString();
        edDate = eventEndDate.getText().toString();
        eAddress = eventAddress.getText().toString();
        ePaid = eventPaid.getText().toString();


        CheckEditText = !TextUtils.isEmpty(eName) && !TextUtils.isEmpty(tyEvent) && !TextUtils.isEmpty(toEvent) &&
                !TextUtils.isEmpty(tAudience) && !TextUtils.isEmpty(sDescription) && !TextUtils.isEmpty(esTime) && !TextUtils.isEmpty(edTime) &&
                !TextUtils.isEmpty(esDate) && !TextUtils.isEmpty(edDate) && !TextUtils.isEmpty(eAddress) && !TextUtils.isEmpty(ePaid);

    }

    private void UserRegisterFunction(final String eventName, final String typeEvent, final String topicEvent, final String targetAudience, final String shortDescription,
                                      final String eventStartTime, final String eventEndTime, final String eventStartDate, final String eventEndDate,
                                      final String eventAddress, final String eventPaid,final String instituteEmail){

        @SuppressLint("StaticFieldLeak")
        class UserRegisterFunctionClass extends AsyncTask<String,Void,String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                progressDialog = ProgressDialog.show(getActivity(),"Loading Data",null,true,true);
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {

                super.onPostExecute(httpResponseMsg);

                progressDialog.dismiss();
                Intent intent = new Intent(getActivity(), UserHome.class);
                startActivity(intent);
                 if (httpResponseMsg.contains("Registration Successfully")) {
                     Toast.makeText(getActivity(), "Registration Successfully", Toast.LENGTH_LONG).show();
                 }

                else if (httpResponseMsg.contains("Failed")){
                    Toast.makeText(getActivity(),"You are student if you want to register event you have to register your institute",Toast.LENGTH_LONG).show();
                 }

                
            }

            @Override
            protected String doInBackground(String... params) {

                hashMap.put("eventName",params[0]);

                hashMap.put("typeEvent",params[1]);

                hashMap.put("topicEvent",params[2]);

                hashMap.put("targetAudience",params[3]);

                hashMap.put("shortDescription",params[4]);

                hashMap.put("eventStartTime",params[5]);

                hashMap.put("eventEndTime",params[6]);

                hashMap.put("eventStartDate",params[7]);

                hashMap.put("eventEndDate",params[8]);

                hashMap.put("eventAddress",params[9]);

                hashMap.put("eventPaid",params[10]);

                hashMap.put("instituteEmail",params[11]);

                finalResult = backgroundRegister.postRequest(hashMap, HttpURL);

                return finalResult;
            }
        }

        UserRegisterFunctionClass userRegisterFunctionClass = new UserRegisterFunctionClass();
        userRegisterFunctionClass.execute(eventName,typeEvent,topicEvent,targetAudience,shortDescription,eventStartTime,eventEndTime,
                        eventStartDate,eventEndDate,eventAddress,eventPaid,instituteEmail);
    }

}
