package com.android.globee;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Objects;

@RequiresApi(api = Build.VERSION_CODES.M)
public class Dashboard extends Fragment {
    private static final String DATA_URL = "https:/stilted-cries.000webhostapp.com/dashboard.php";
    private TextView studentName;
    private TextView studentEmail;
      private String studentsEmail;
    private ProgressDialog progressDialog;

    public Dashboard() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        studentName = view.findViewById(R.id.studentNames);
        studentEmail = view.findViewById(R.id.studentsEmails);



     //   registeredEvent2= view.findViewById(R.id.registerdEvent2);

        TextView passwordChanges = view.findViewById(R.id.passwordChanges);
        passwordChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PasswordChanges passwordChanges = new PasswordChanges();
                //noinspection deprecation
                FragmentManager fm = getFragmentManager();
                assert fm != null;
                FragmentTransaction fragmentTransaction = fm.beginTransaction();
                fragmentTransaction.replace(R.id.dashboard,passwordChanges);
                fragmentTransaction.commit();
            }
        });

        SessionManagement sessionManagement = new SessionManagement(getActivity());
        sessionManagement.checkLogin();
        HashMap<String, String>  student = sessionManagement.getUserDetails();
        studentsEmail = student.get(SessionManagement.KEY_EMAIL);

        MyAsyncTasks myAsyncTasks = new MyAsyncTasks();
        myAsyncTasks.execute();
      return view;
    }


@SuppressLint("StaticFieldLeak")
public class MyAsyncTasks extends AsyncTask<String, String, String> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // display a progress dialog for good user experiance
            progressDialog = new ProgressDialog(getContext());
            progressDialog.setMessage("Please Wait");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {



            // implement API in background and store the response in current variable
         String current = "";
            try {
                URL url;
                HttpURLConnection urlConnection = null;
                try {
                    url = new URL(DATA_URL);

                    urlConnection = (HttpURLConnection) url.openConnection();

                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    Uri.Builder builder = new Uri.Builder()
                            .appendQueryParameter("studentEmail", studentsEmail);



                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, StandardCharsets.UTF_8));

                    writer.write(Objects.requireNonNull(builder.build().getEncodedQuery()));
                    writer.flush();
                    writer.close();
                    os.close();
                    urlConnection.connect();

                    InputStream in = urlConnection.getInputStream();

                    InputStreamReader isw = new InputStreamReader(in);

                    int data = isw.read();
                    while (data != -1) {
                        current += (char) data;
                        data = isw.read();
                        System.out.print(current);

                    }
                    // return the data to onPostExecute method
                    return current;

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                return "Exception: " + e.getMessage();
            }
            return current;
        }

        @Override
        protected void onPostExecute(String s) {

         // dismiss the progress dialog after receiving data from API
            progressDialog.dismiss();
            try {
                // JSON Parsing of data
                JSONArray jsonArray = new JSONArray(s);

                JSONObject oneObject = jsonArray.getJSONObject(0);
                // Pulling items from the array
                String sname = oneObject.getString("sname");
                String semail = oneObject.getString("semail");

                Log.i("Sname",sname);
                Log.i("Semail",semail);

                // display the data in UI
                studentName.setText(sname);
                studentEmail.setText(semail);


            } catch (JSONException e) {

                e.printStackTrace();
            }


        }

    }
}
