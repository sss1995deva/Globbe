package com.android.globee;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@RequiresApi(api = Build.VERSION_CODES.M)
public class Home extends Fragment implements RecyclerView.OnScrollChangeListener{

    //Data URL
    private static final String DATA_URL = "https:/stilted-cries.000webhostapp.com/newsfeed.php?page=";

    //JSON TAGS
    private static final String I_NAME = "instituteName";
    private static final String EVENT_NAME = "eventName";
    private static final String TYPE_EVENT = "typeEvent";
    private static final String TIME_STAMP = "timeStamp";
    private static final String TOPIC_EVENT = "topicEvent";
    private static final String TARGET_AUDIENCE = "targetAudience";
    private static final String SHORT_DESCRIPTION = "shortDescription";
    private static final String  EVENT_START_TIME = "eventstartTime";
    private static final String  EVENT_END_TIME = "eventendTime";
    private static final String EVENT_START_DATE = "eventstartDate";
    private static final String EVENT_END_DATE = "eventendtDate";
    private static final String  EVENT_ADDRESS = "eventAddress";
    private static final String EVENT_PAID = "eventPaid";

    //Creating a List of superheroes
    private List<SuperHero> listSuperHeroes;
    private View view;
    //Creating Views
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;

    //Volley Request Queue
    private RequestQueue requestQueue;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;
    public Home() {}

     @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

         view = inflater.inflate(R.layout.fragment_home, container, false);
         //Initializing Views
         recyclerView = view.findViewById(R.id.recyclerView);
         recyclerView.setHasFixedSize(true);
         RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
         recyclerView.setLayoutManager(layoutManager);


         //Initializing our superheroes list
         listSuperHeroes = new ArrayList<>();
         requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()));

         //Calling method to get data to fetch data
         getData();

         //Adding an scroll change listener to recyclerview
         recyclerView.setOnScrollChangeListener(this);

         //initializing our adapter
         adapter = new CardAdapter(listSuperHeroes, getContext());

         //Adding adapter to recyclerview
         recyclerView.setAdapter(adapter);

         return view;
    }

    //Request to get json from server we are passing an integer here
    //This integer will used to specify the page number for the request ?page = requestcount
    //This method would return a JsonArrayRequest that will be added to the request queue
    private JsonArrayRequest getDataFromServer(int requestCount) {
        //Initializing ProgressBar
        final ProgressBar progressBar = view.findViewById(R.id.progressBar1);

        //Displaying Progressbar
        progressBar.setVisibility(View.VISIBLE);
        //  setProgressBarIndeterminateVisibility(true);

        //JsonArrayRequest of volley

        //Returning the request
        return new JsonArrayRequest(DATA_URL + requestCount,
                new Response.Listener<JSONArray>() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(JSONArray response) {
                        //Calling method parseData to parse the json response
                        parseData(response);
                        //Hiding the progressbar
                        progressBar.setVisibility(View.GONE);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                        //If an error occurs that means end of the list has reached
//                        Toast.makeText(getActivity(), "No More Items Available", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    //This method will get data from the web api
    private void getData() {
        //Adding the method to the queue by calling the method getDataFromServer
        requestQueue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    //This method will parse json data
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void parseData(JSONArray array) {
        for (int i = 0; i < array.length(); i++) {
            //Creating the superhero object
            SuperHero superHero = new SuperHero();
            try {
                /* Getting json */
                JSONObject json = array.getJSONObject(i);

                //Adding data to the superhero object
                superHero.setInstituteName(json.getString(I_NAME));
                superHero.setEventName(json.getString(EVENT_NAME));


//                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//                sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
//                long time = sdf.parse(TIME_STAMP).getTime();
//
//               superHero.setTimeStamps(UnixToHuman.getTimeAgo(time));

                superHero.setTimeStamps(json.getString(TIME_STAMP));

                superHero.setTypeOfEvent(json.getString(TYPE_EVENT));
                superHero.setTopicOfEvent(json.getString(TOPIC_EVENT));
                superHero.setTargetAudience(json.getString(TARGET_AUDIENCE));
                superHero.setEventstartTime(json.getString(EVENT_START_TIME));
                superHero.setEventendTime(json.getString(EVENT_END_TIME));
                superHero.setEventstartDate(json.getString(EVENT_START_DATE));
                superHero.setEventendDate(json.getString(EVENT_END_DATE));
                superHero.setEventAddress(json.getString(EVENT_ADDRESS));
                superHero.setShortDescription(json.getString(SHORT_DESCRIPTION));
                superHero.setEventPaid(json.getString(EVENT_PAID));

            } catch (JSONException e) {
                e.printStackTrace();
            }
            //Adding the superhero object to the list
            listSuperHeroes.add(superHero);
        }

        //Notifying the adapter that data has been added or changed
        adapter.notifyDataSetChanged();
    }

    //This method would check that the recyclerview scroll has reached the bottom or not
    private boolean isLastItemDisplaying(RecyclerView recyclerView) {
        if (Objects.requireNonNull(recyclerView.getAdapter()).getItemCount() != 0) {
            int lastVisibleItemPosition = ((LinearLayoutManager) Objects.requireNonNull(recyclerView.getLayoutManager())).findLastCompletelyVisibleItemPosition();
            return lastVisibleItemPosition != RecyclerView.NO_POSITION && lastVisibleItemPosition == recyclerView.getAdapter().getItemCount() - 1;
        }
        return false;
    }

    @Override
    public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
        //Ifscrolled at last then
        if (isLastItemDisplaying(recyclerView)) {
            //Calling the method getdata again
                 getData();
        }
    }

}
