<?php 
     $db =  "id9857698_newdb";//"test";
  $user = "id9857698_root1234";
  $pass = "12345678";
  $host = "localhost";
    
    if($_SERVER['REQUEST_METHOD']=='POST'){
    $con = mysqli_connect($host,$user,$pass,$db);
         $semail =  $_POST['studentEmail'];
        //Adding results to an array 
        $res = array();  $start = 0; 
      $data=mysqli_fetch_array(mysqli_query($con,"SELECT COUNT(eventName) AS total FROM eventRegister"));
      $limit =  $data['total'];
      

      $insterst = mysqli_fetch_array(mysqli_query($con,"SELECT sinterest FROM Student WHERE semail = '$semail'"));
      $sinterests = $insterst['sinterest'];
      

      $result = mysqli_query($con,"SELECT * FROM eventRegister WHERE iemail = '$semail' ORDER BY date DESC limit $start, $limit");

if(mysqli_num_rows($result)>0)  {
while($row = mysqli_fetch_array($result)){
      
                 array_push($res, array(
 
                "time" =>$row['date'],

                "sname"=>$row['sname'],
                
                "eventName"=>$row['eventName'])
              );
                
 }      }    
 else{
  if($results = mysqli_query($con,"SELECT instituteName,typeEvent,topicEvent FROM event WHERE MATCH(topicEvent) AGAINST('$sinterests' IN NATURAL LANGUAGE MODE)")){
      while($row = mysqli_fetch_array($results)){

               array_push($res, array(
                 
                 "sname"=>$row['instituteName'],

                "eventName"=>$row['topicEvent'],
               
                "time"=>$row['typeEvent'])
                
                );
    }   }   }
      
        mysqli_error($con);
        //Displaying the array in json format 
        echo json_encode($res)."\n";
    mysqli_close($con);
    }
 ?>