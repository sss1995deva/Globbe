<?php
$db =    "id9857698_newdb";//"test";
$user = "id9857698_root1234";
$pass = "12345678";
$host = "localhost";

$conn = mysqli_connect($host,$user,$pass,$db);

$semail =    $_POST['studentEmail'];
$spassword =  $_POST['studentPassword'];

if($conn)
{
        echo("Connected");
      if(mysqli_num_rows(mysqli_query($conn,"SELECT * FROM Student where semail like '$semail' and spassword like '$spassword'"))>0){
        echo("LOGIN");
     }
     elseif (mysqli_num_rows(mysqli_query($conn,"SELECT * FROM Institute where iemail like '$semail' and ipassword like '$spassword'"))>0) {
          echo("LOGIN");
     }
     else
     {
        echo("Login failed");
     }
}
else
{
    echo "Not connected....";
}


?>

