package com.android.globee;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterInstitute extends Fragment {
    EditText instituteName,instituteEmail,institutePhone,instituteAddress,institutePassword,instituteConfirmPassword;
    Button register;
    Button log_in;
    String iName,iEmail,iPhone,iAddress,iPassword,icPassword;
    String finalResult ;
    String HttpURL = "https:/stilted-cries.000webhostapp.com/institute.php";
    Boolean CheckEditText ;
    ProgressDialog progressDialog;
    HashMap<String,String> hashMap = new HashMap<>();
    BackgroundRegister backgroundRegister = new BackgroundRegister();

      public RegisterInstitute() {
          }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_register_institute, container, false);


        instituteName =  view.findViewById(R.id.instituteName);
        instituteEmail = view.findViewById(R.id.instituteEmail);
        institutePhone =  view.findViewById(R.id.institutePhone);
        institutePassword =  view.findViewById(R.id.institutePassword);
        instituteConfirmPassword = view.findViewById(R.id.instituteConfirmPassword);
        instituteAddress = view.findViewById(R.id.instituteAddress);

        register =  view.findViewById(R.id.instituteRegister);
        log_in =  view.findViewById(R.id.instituteLogin);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Checking whether EditText is Empty or Not
                CheckEditTextIsEmptyOrNot();

                if(CheckEditText){

                    // If EditText is not empty and CheckEditText = True then this block will execute.

                    UserRegisterFunction(iName,iEmail,iPhone,iAddress,iPassword);

                }
                else {

                    // If EditText is empty then this block will execute .
                    Toast.makeText(getActivity(), "Please fill all form fields.", Toast.LENGTH_LONG).show();

                }


            }
        });
        log_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),UserLogin.class);
                startActivity(intent);
            }
        });

       return view;
    }
    public static boolean isValidPassword(String password) {
        Matcher matcher = Pattern.compile("((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{4,20})").matcher(password);
        return matcher.matches();
    }
    public boolean emailValidator(String email)
    {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
    private boolean isValidMobile(String phone) {
        if(!Pattern.matches("[a-zA-Z]+", phone)) {
            return phone.length() > 9 && phone.length() <= 13;
        }
        return false;
    }
    public void CheckEditTextIsEmptyOrNot(){

        iName = instituteName.getText().toString();
        iEmail = instituteEmail.getText().toString();
        iPhone = institutePhone.getText().toString();
        iAddress = instituteAddress.getText().toString();
        iPassword = institutePassword.getText().toString();
        icPassword = instituteConfirmPassword.getText().toString();


        if(TextUtils.isEmpty(iName) || TextUtils.isEmpty(iEmail) || TextUtils.isEmpty(iPhone) || TextUtils.isEmpty(iAddress)|| TextUtils.isEmpty(iPassword)
                || TextUtils.isEmpty(icPassword))
        {

            CheckEditText = false;

        }
        else if (iPassword.equals(icPassword)) {
            if (isValidPassword(iPassword))
                if (emailValidator(iEmail))
                    if (isValidMobile(iPhone))
                        CheckEditText = true;
                    else
                        Toast.makeText(getActivity(), "Phone number is not Valid.", Toast.LENGTH_SHORT).show();

                else
                    Toast.makeText(getActivity(),"Email is not Valid",Toast.LENGTH_SHORT).show();
            else {
                CheckEditText = false;
                Toast.makeText(getActivity(),"Password must contain mix of upper and lower case letters as well as digits and one special charecter(4-20)",Toast.LENGTH_LONG).show();

            }
        }

        else {
            Toast.makeText(getActivity(), "Both password not match.", Toast.LENGTH_LONG).show();
            CheckEditText = false;
        }

    }

    public void UserRegisterFunction(final String instituteName,final String instituteEmail,final String institutePhone,final String instituteAddress,final String institutePassword){

        @SuppressLint("StaticFieldLeak")
        class UserRegisterFunctionClass extends AsyncTask<String,Void,String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                progressDialog = ProgressDialog.show(getActivity(),"Loading Data",null,true,true);
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {

                super.onPostExecute(httpResponseMsg);

                progressDialog.dismiss();
                if(httpResponseMsg.contains("Registration Successfully")) {
                    Toast.makeText(getActivity(), "Registration Successfully,You have to Login now", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getActivity(), UserLogin.class);
                    startActivity(intent);
                }
                else if (httpResponseMsg.contains("Email Already Exists"))
                {
                    Toast.makeText(getActivity(), "Email Already Exists", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getActivity(), UserLogin.class);
                    startActivity(intent);
                }
            }

            @Override
            protected String doInBackground(String... params) {

                hashMap.put("instituteName",params[0]);

                hashMap.put("instituteEmail",params[1]);

                hashMap.put("institutePhone",params[2]);

                hashMap.put("instituteAddress",params[3]);

                hashMap.put("institutePassword",params[4]);

                finalResult = backgroundRegister.postRequest(hashMap, HttpURL);

                return finalResult;
            }
        }

        UserRegisterFunctionClass userRegisterFunctionClass = new UserRegisterFunctionClass();
        userRegisterFunctionClass.execute(instituteName,instituteEmail,institutePhone,instituteAddress,institutePassword);
    }
}
