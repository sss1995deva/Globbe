<?php
$db =    "id9857698_newdb";//"test";
$user = "id9857698_root1234";
$pass = "12345678";
$host = "localhost";

if($_SERVER['REQUEST_METHOD']=='POST'){

	$con = mysqli_connect($host,$user,$pass,$db);

    $eName= $_POST['eventName'];
	$tyEvent = $_POST['typeEvent'];
	$toEvent = $_POST['topicEvent'];
	$tAudience = $_POST['targetAudience'];
	$sDescription = $_POST['shortDescription'];
	$esTime= $_POST['eventStartTime'];
	$edTime = $_POST['eventEndTime'];
	$esDate = $_POST['eventStartDate'];
	$edDate = $_POST['eventEndDate'];
	$eAddress = $_POST['eventAddress'];
	$ePaid = $_POST['eventPaid'];
    $instituteEmail = $_POST['instituteEmail'];
    
    
     $SqlQuery = "INSERT INTO event (iemail,instituteName,eventName,typeEvent,topicEvent,targetAudience,shortDescription,
                  eventstartTime,eventendTime,eventstartDate,eventendDate,eventAddress,eventPaid) VALUES
                  ('$instituteEmail',(SELECT instituteName FROM Institute WHERE iemail = '$instituteEmail'),'$eName','$tyEvent','$toEvent','$tAudience','$sDescription','$esTime','$edTime','$esDate','$edDate','$eAddress','$ePaid')";

		if (mysqli_query($con,$SqlQuery)) {
			echo "Registration Successfully";
		}
		else{
		echo "Failed";
		echo mysqli_error($con);
    	}
       mysqli_close($con);							
}
?>