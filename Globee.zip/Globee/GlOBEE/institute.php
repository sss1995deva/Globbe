<?php
$db =    "id9857698_newdb";//"test";
$user = "id9857698_root1234";
$pass = "12345678";
$host = "localhost";

if($_SERVER['REQUEST_METHOD']=='POST'){

	$con = mysqli_connect($host,$user,$pass,$db);

	$iname = $_POST['instituteName'];
	$iemail = $_POST['instituteEmail'];
	$iphone = $_POST['institutePhone'];
	$iaddress = $_POST['instituteAddress'];
	$ipassword = $_POST['institutePassword'];
	

	$checkSql = "SELECT * FROM Institute WHERE iemail = '$iemail'";

	$check = mysqli_fetch_array(mysqli_query($con,$checkSql));

	if(isset($check)){
		echo "Email Already Exists";
	}
	else
	{
		$SqlQuery = "INSERT INTO Institute (instituteName,iemail,iphone,iaddress,ipassword) values('$iname','$iemail','$iphone','iaddress','$ipassword')";

		if (mysqli_query($con,$SqlQuery)) {
			echo "Registration Successfully";
		}
		else{
		echo "Something Went Wrong";
}

 	}
       mysqli_close($con);							
}
