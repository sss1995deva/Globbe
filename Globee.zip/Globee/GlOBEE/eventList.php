<?php
   $db =  "id9857698_newdb";
  $user = "id9857698_root1234";
  $pass = "12345678";
  $host = "localhost";
if($_SERVER['REQUEST_METHOD']=='POST'){
         $con = mysqli_connect($host,$user,$pass,$db);
         $semail = $_POST['studentEmail'];  
         $res = array(); $i = 0;
if ($con) {
            
              $res = array(); 
             $i = 0;
if(mysqli_num_rows(mysqli_query($con,"SELECT eventName FROM event WHERE iemail ='$semail'"))>0)
  {
   while($row = mysqli_fetch_array(mysqli_query($con,"SELECT eventName FROM event WHERE iemail ='$semail'"))){
                   
                   if($i>0)
                      break;
                  else
                  {
                    $i++;
               array_push($res, array(
                           "data"=>$row['eventName']));    
                }
 }
}
    else{
     if($result = mysqli_query($con,"SELECT eventName FROM eventRegister WHERE semail = '$semail'"))
      {
      while($row = mysqli_fetch_array($result)){

            array_push($res, array(

                       "data"=>$row['eventName']));    
                                 
          }
      }
 
    }    
    mysqli_error($con);
        //Displaying the array in json format 
        echo json_encode($res);
    mysqli_close($con);
}
}
?>