<?php
$db =    "id9857698_newdb";//"test";
$user = "id9857698_root1234";
$pass = "12345678";
$host = "localhost";

if($_SERVER['REQUEST_METHOD']=='POST'){

	$con = mysqli_connect($host,$user,$pass,$db);

	$sname = $_POST['studentName'];
	$semail = $_POST['studentEmail'];
	$scourse = $_POST['studentCourse'];
	$sstream = $_POST['studentStream'];
	$sinterest = $_POST['studentInterest'];
	$sphone = $_POST['studentPhone'];
	$spassword = $_POST['studentPassword'];

	$checkSql = "SELECT * FROM Student WHERE semail = '$semail'";

	$check = mysqli_fetch_array(mysqli_query($con,$checkSql));

	if(isset($check)){
		echo "Email Already Exists";
	}
	else
	{
		$SqlQuery = "INSERT INTO Student (sname,semail,scourse,sstream,sinterest,sphone,spassword) values('$sname','$semail','$scourse','$sstream','$sinterest','$sphone','$spassword')";

		if (mysqli_query($con,$SqlQuery)) {
			echo "Registration Successfully";
		}
		else{
		echo "Something Went Wrong";
}

 	}
       mysqli_close($con);							
}
