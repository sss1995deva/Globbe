package com.android.globee;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

public class UserLogin extends AppCompatActivity {
    EditText studentEmail,studentPassword;
    Button loginButton,register;
    String sEmail,sPassword;

    SessionManagement sessionManagement;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManagement = new SessionManagement(getApplicationContext());

       loginButton = findViewById(R.id.loginButton);
       studentEmail = findViewById(R.id.studentEmail);
       studentPassword = findViewById(R.id.studentPassword);

       register = findViewById(R.id.register);
       register.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(getApplicationContext(), UserRegister.class);
               intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
           }
       });
    }

    public void loginBtn(View view) {

        sEmail = studentEmail.getText().toString();
        sPassword = studentPassword.getText().toString();

        BackgroundLogin background = new BackgroundLogin(this);
        background.execute(sEmail,sPassword);

    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }

    @SuppressLint("StaticFieldLeak")
   public class BackgroundLogin extends AsyncTask<String,Void,String> {
        AlertDialog dialog;
        Context context;
       String studentEmail,studentPassword;

        BackgroundLogin(Context context){
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            dialog = new AlertDialog.Builder(context).create();
            dialog.setTitle("Login Status");
        }

        @Override
        protected void onPostExecute(String s) {
            if (s.contains("LOGIN"))
            {
                sessionManagement.createLoginSession(studentEmail,studentPassword);
                Intent intent = new Intent(getApplicationContext(), UserHome.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                context.startActivity(intent);
             }
           else
            {
                dialog.setMessage(s);
                dialog.show();
            }
        }

        @Override
        protected String doInBackground(String... voids) {
            StringBuilder result = new StringBuilder();
            studentEmail = voids[0];
            studentPassword = voids[1];

            String connstr = "https:/stilted-cries.000webhostapp.com/login.php";

            try{
                URL url  = new URL(connstr);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.setDoOutput(true);

                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));
                String data = URLEncoder.encode("studentEmail","UTF-8")+"="+URLEncoder.encode(studentEmail,"UTF-8")
                        +"&&"+ URLEncoder.encode("studentPassword","UTF-8")+"="+URLEncoder.encode(studentPassword,"UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));
                String line;
                while (null != (line = bufferedReader.readLine())){
                    result.append(line);
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result.toString();

            } catch (IOException e) {
                result = new StringBuilder(Objects.requireNonNull(e.getMessage()));
            }
            return result.toString();
        }


    }

}
