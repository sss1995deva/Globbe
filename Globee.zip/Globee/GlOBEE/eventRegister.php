<?php
$db =    "id9857698_newdb";//"test";
$user = "id9857698_root1234";
$pass = "12345678";
$host = "localhost";

if($_SERVER['REQUEST_METHOD']=='POST'){

	$con = mysqli_connect($host,$user,$pass,$db);
     
    $instituteName = $_POST['insName'];

    $eventName = $_POST['esName'];
 
    $semail = $_POST['studentEmail'];

    $checkSql = "SELECT * FROM eventRegister WHERE eventName = '$eventName' AND semail = '$semail'";
    
    $result = mysqli_fetch_array(mysqli_query($con,"SELECT iemail FROM Institute WHERE iemail = '$semail'"));
    
    $check = mysqli_fetch_array(mysqli_query($con,$checkSql));
    
    if(isset($check)){
		echo "Email Already Exists";
	}
	else if(isset($result))
	{
	    echo "Institute Email";
	}
	else{
       
    $sql = "INSERT INTO eventRegister(iemail,instituteName,eventName,sname,semail,sphone) 
                         VALUES((SELECT iemail FROM Institute WHERE instituteName = '$instituteName'),'$instituteName','$eventName',
                         (SELECT sname FROM Student WHERE semail = '$semail'),'$semail',(SELECT sphone FROM Student WHERE semail = '$semail'))";
	
        if (mysqli_query($con,$sql)) {
			echo "Registration Successfully";
	            }
		else{

		echo "Something Went Wrong";
		echo mysqli_error($con);

		}
 	}
       mysqli_close($con);		


}
?> 
