package com.android.globee;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RegisterStudent extends Fragment implements AdapterView.OnItemSelectedListener {
    Button register, log_in;
    EditText studentName,studentEmail,studentPassword,studentInterest,studentPhone,studentConfirmPassword ;
    String sName,sEmail,sPassword,sCourse,sInterest,sStream,sPhone,scPassword;
    String finalResult ;
    String HttpURL = "https:/stilted-cries.000webhostapp.com/student.php";
    Boolean CheckEditText = false ;
    ProgressDialog progressDialog;
    HashMap<String,String> hashMap = new HashMap<>();
    BackgroundRegister backgroundRegister = new BackgroundRegister();
    Spinner studentCourse,studentStream;
    String[] courses = {"Select Course","B.E","B.Arch","B.Com","B.Sc","B.A"};
    String[] streams = {"Select Branch","CSE","IT","ME","CA"};

    public  RegisterStudent(){}


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register_student, container, false);
        studentName = view.findViewById(R.id.studentName);
        studentEmail = view.findViewById(R.id.studentEmail);

        studentCourse = view.findViewById(R.id.studentCourse);
         //Creating the ArrayAdapter instance having the country list
        ArrayAdapter<String> course = new ArrayAdapter<>(this.getActivity(), android.R.layout.simple_spinner_item,courses);
        course.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        studentCourse.setAdapter(course);
        studentCourse.setOnItemSelectedListener(this);

        studentStream = view.findViewById(R.id.studentStream);
         //Creating the ArrayAdapter instance having the country list
        ArrayAdapter<String> stream = new ArrayAdapter<>(this.getActivity(), android.R.layout.simple_spinner_item,streams);
        stream.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        studentStream.setAdapter(stream);
        studentStream.setOnItemSelectedListener(this);


        studentInterest = view.findViewById(R.id.studentInterest);
        studentPhone = view.findViewById(R.id.studentPhonen);
        studentPassword = view.findViewById(R.id.studentPassword);
        studentConfirmPassword = view.findViewById(R.id.studentConfirmPassword);

        studentPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        studentPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        studentPassword.setSelection(studentPassword.length());

        register = view.findViewById(R.id.registerButton);
        log_in =  view.findViewById(R.id.loginButton);

        //Adding Click Listener on button.
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Checking whether EditText is Empty or Not
                CheckEditTextIsEmptyOrNot();

                if(CheckEditText){

                    // If EditText is not empty and CheckEditText = True then this block will execute.

                    UserRegisterFunction(sName,sEmail,sCourse,sStream,sInterest,sPhone,sPassword);

                }
                else {

                    // If EditText is empty then this block will execute .
                    Toast.makeText(getActivity(), "Please fill all form fields.", Toast.LENGTH_LONG).show();

                }


            }
        });

        log_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity(),UserLogin.class);
                startActivity(intent);

            }
        });
        return view;
    }
    public static boolean isValidPassword(String password) {
        Matcher matcher = Pattern.compile("((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{4,20})").matcher(password);
        return matcher.matches();
    }
    public boolean emailValidator(String email)
    {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
    private boolean isValidMobile(String phone) {
        if(!Pattern.matches("[a-zA-Z]+", phone)) {
            return phone.length() > 9 && phone.length() <= 13;
        }
        return false;
    }
    public void CheckEditTextIsEmptyOrNot(){

        sName = studentName.getText().toString();
        sEmail = studentEmail.getText().toString();

      //  sCourse = studentCourse.getText().toString();
       // sStream = studentStream.getText().toString();

        sInterest = studentInterest.getText().toString();
        sPhone = studentPhone.getText().toString();
        sPassword = studentPassword.getText().toString();
        scPassword = studentConfirmPassword.getText().toString();

        if(TextUtils.isEmpty(sName) || TextUtils.isEmpty(sEmail) || TextUtils.isEmpty(sCourse) || TextUtils.isEmpty(sStream)|| TextUtils.isEmpty(sInterest)
                || TextUtils.isEmpty(sPhone)|| TextUtils.isEmpty(sPassword)|| TextUtils.isEmpty(scPassword))
        {

            CheckEditText = false;

        }
        else if (sPassword.equals(scPassword)) {
            if (isValidPassword(sPassword))
                    if (emailValidator(sEmail))
                         if (isValidMobile(sPhone))
                              CheckEditText = true;
                         else
                             Toast.makeText(getActivity(), "Phone number is not Valid.", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getActivity(),"Email is not Valid.",Toast.LENGTH_SHORT).show();
            else {
                CheckEditText = false;
                Toast.makeText(getActivity(),"Password must contain mix of upper and lower case letters as well as digits and one special charecter(4-20)",Toast.LENGTH_LONG).show();

            }
        }
         else {
            Toast.makeText(getActivity(), "Both password not match.", Toast.LENGTH_LONG).show();
            CheckEditText = false;
        }

    }

    public void UserRegisterFunction(final String studentName,final String studentEmail,final String studentCourse,final String studentStream,final String studentInterest,final String studentPhone,final String studentPassword){

        @SuppressLint("StaticFieldLeak")
        class UserRegisterFunctionClass extends AsyncTask<String,Void,String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                progressDialog = ProgressDialog.show(getActivity(),"Loading Data",null,true,true);
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {

                super.onPostExecute(httpResponseMsg);

                progressDialog.dismiss();
                if(httpResponseMsg.contains("Registration Successfully")) {
                   Toast.makeText(getActivity(), "Registration Successfully,You have to Login now", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getActivity(), UserLogin.class);
                    startActivity(intent);
                }
                else if (httpResponseMsg.contains("Email Already Exists"))
                {
                    Toast.makeText(getActivity(), "Email Already Exists", Toast.LENGTH_LONG).show();
                   Intent intent = new Intent(getActivity(), UserLogin.class);
                    startActivity(intent);
                 }
          }

            @Override
            protected String doInBackground(String... params) {

                hashMap.put("studentName",params[0]);

                hashMap.put("studentEmail",params[1]);

                hashMap.put("studentCourse",params[2]);

                hashMap.put("studentStream",params[3]);

                hashMap.put("studentInterest",params[4]);

                hashMap.put("studentPhone",params[5]);

                hashMap.put("studentPassword",params[6]);

                finalResult = backgroundRegister.postRequest(hashMap, HttpURL);

                return finalResult;
            }
        }

        UserRegisterFunctionClass userRegisterFunctionClass = new UserRegisterFunctionClass();
        userRegisterFunctionClass.execute(studentName,studentEmail,studentCourse,studentStream,studentInterest,studentPhone,studentPassword);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId() == R.id.studentCourse)
        {
            sStream = String.valueOf(parent.getItemAtPosition(position));
        }
        else if(parent.getId() == R.id.studentStream)
        {
            sCourse  =String.valueOf(parent.getItemAtPosition(position));
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
